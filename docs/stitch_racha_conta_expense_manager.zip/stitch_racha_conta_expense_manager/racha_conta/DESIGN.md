---
name: Racha-Conta
colors:
  surface: '#f8f9fb'
  surface-dim: '#d9dadc'
  surface-bright: '#f8f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f6'
  surface-container: '#edeef0'
  surface-container-high: '#e7e8ea'
  surface-container-highest: '#e1e2e4'
  on-surface: '#191c1e'
  on-surface-variant: '#4a4455'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f3'
  outline: '#7b7487'
  outline-variant: '#ccc3d8'
  surface-tint: '#732ee4'
  primary: '#630ed4'
  on-primary: '#ffffff'
  primary-container: '#7c3aed'
  on-primary-container: '#ede0ff'
  inverse-primary: '#d2bbff'
  secondary: '#6e3aca'
  on-secondary: '#ffffff'
  secondary-container: '#8856e5'
  on-secondary-container: '#fffbff'
  tertiary: '#005b3d'
  on-tertiary: '#ffffff'
  tertiary-container: '#007650'
  on-tertiary-container: '#76ffc2'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#eaddff'
  primary-fixed-dim: '#d2bbff'
  on-primary-fixed: '#25005a'
  on-primary-fixed-variant: '#5a00c6'
  secondary-fixed: '#ebddff'
  secondary-fixed-dim: '#d3bbff'
  on-secondary-fixed: '#250059'
  on-secondary-fixed-variant: '#581db3'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f8f9fb'
  on-background: '#191c1e'
  surface-variant: '#e1e2e4'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  container-padding-mobile: 16px
  container-padding-desktop: 32px
  gutter: 24px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
---

## Brand & Style
The brand personality is collaborative, transparent, and effortlessly efficient. It targets young adults and students living in shared housing who require a tool that feels as reliable as a fintech app but as intuitive and clean as a modern productivity suite.

The design system adopts a **Modern Fintech** style characterized by high-precision typography, generous white space, and a refined use of depth. It blends the structural clarity of Linear with the soft, approachable aesthetics of modern digital banking. The interface prioritizes clarity of information—debts, credits, and transactions—using a limited but punchy color palette to drive action and status recognition.

## Colors
The palette is rooted in a vibrant "Electric Purple" that signifies action and modernization of shared finances. 

- **Primary & Secondary:** Used for brand presence, primary actions, and active navigation states.
- **Surface & Background:** The default background is a very light gray (#F3F4F6) to reduce eye strain compared to pure white, while "White" is reserved for elevated cards and containers.
- **Semantic Colors:** A crisp Emerald Green handles "Paid" or "Settled" statuses, while a soft Coral Red indicates "Pending" or "Overdue" amounts.
- **Dark Mode:** This design system scales into dark mode by swapping the light gray background for a deep charcoal (#0F172A) and adjusting surface colors to semi-transparent overlays, maintaining the vibrancy of the primary purple.

## Typography
This design system utilizes **Inter** exclusively to achieve a systematic, utilitarian aesthetic that remains highly legible at small sizes. 

The hierarchy is built on tight line-heights and slight negative letter-spacing for headings to mimic the "SaaS" look of high-end engineering tools. Quantitative data (monetary values) should always use the `label-md` or `headline-md` weights to ensure financial figures are the most prominent elements on the page.

## Layout & Spacing
The layout follows a **Fluid Grid** model with a focus on vertical "stacks." 

- **Desktop:** A 12-column grid with 24px gutters. Content is often contained within a centered max-width container (1280px) or a sidebar-anchored fluid dashboard.
- **Sidebar:** A fixed 260px left-hand navigation is preferred for the desktop experience.
- **Mobile:** A single-column flow with 16px side margins. 
- **Spacing Rhythm:** An 8px linear scale is used for all padding and margins to maintain mathematical harmony across the UI.

## Elevation & Depth
The system uses **Ambient Shadows** and **Tonal Layers** to define hierarchy. 

Shadows are extremely soft, utilizing a multi-layered approach with a hint of the primary purple in the shadow's umbra to create a "glow" effect on white surfaces. 
- **Level 1 (Base):** Flat background (#F3F4F6).
- **Level 2 (Cards):** White surface with a `0px 4px 20px rgba(124, 58, 237, 0.05)` shadow.
- **Level 3 (Modals/Popovers):** White surface with a `0px 12px 32px rgba(0, 0, 0, 0.1)` shadow.

Interactive elements use a subtle inner-border (1px) in a slightly darker shade than the surface to provide crispness without looking "heavy."

## Shapes
The shape language is friendly and modern. The design system defaults to a **Rounded** configuration. 

- **Standard Components:** 0.5rem (8px) for small inputs and tags.
- **Cards & Containers:** 1rem (16px) to give the UI a soft, approachable feel typical of modern fintech apps.
- **Buttons:** 0.75rem (12px) for a comfortable, "clickable" touch target.

## Components

### Buttons
Primary buttons use the #7C3AED fill with white text. They should have a subtle top-down gradient and a scale-down effect (98%) on click. Secondary buttons use a light purple tint with purple text.

### Cards
Cards are the primary container for expense details. They feature 16px corner radius, white backgrounds (or dark gray in dark mode), and a 1px border (#E5E7EB) to ensure visibility against the light gray background.

### Input Fields
Inputs are minimalist: a 1px border that turns Primary Purple on focus, with a soft purple outer glow. Labels are positioned above the field using `label-sm`.

### Chips / Status Indicators
Used for "Paid," "Pending," or "Settle Up." These are pill-shaped with low-opacity background tints of green or red and high-contrast text.

### Sidebar
The sidebar is "floating" or "detached" from the screen edge on desktop, using a transparent background with blurred glassmorphism effects or a clean neutral tint to separate navigation from the workspace.

### List Items
Transactions are displayed in clean rows with a leading icon (circular, containing a category icon) and trailing metadata (amount and date). Rows should have a hover state that highlights the entire line in a light neutral tint.