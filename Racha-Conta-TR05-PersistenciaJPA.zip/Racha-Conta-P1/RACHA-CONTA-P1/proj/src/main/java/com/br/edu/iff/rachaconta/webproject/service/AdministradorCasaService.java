package com.br.edu.iff.rachaconta.webproject.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.br.edu.iff.rachaconta.webproject.dto.AdministradorCasaDTO;
import com.br.edu.iff.rachaconta.webproject.model.AdministradorCasa;
import com.br.edu.iff.rachaconta.webproject.repository.AdministradorCasaRepository;

@Service
public class AdministradorCasaService {

    private final AdministradorCasaRepository repository;

    public AdministradorCasaService(AdministradorCasaRepository repository) {
        this.repository = repository;
    }

    public List<AdministradorCasa> listar() {
        return repository.findAll();
    }

    public AdministradorCasa buscar(Long id) {
        return repository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Administrador não encontrado."));
    }

    public AdministradorCasa salvar(AdministradorCasaDTO dto) {
        validar(dto);
        AdministradorCasa administrador = new AdministradorCasa(
            null,
            dto.nome(),
            dto.email(),
            dto.nivelAcesso()
        );
        return repository.save(administrador);
    }

    public AdministradorCasa atualizar(Long id, AdministradorCasaDTO dto) {
        validar(dto);
        AdministradorCasa administrador = buscar(id);
        administrador.setNome(dto.nome());
        administrador.setEmail(dto.email());
        administrador.setNivelAcesso(dto.nivelAcesso());
        return repository.save(administrador);
    }

    public void excluir(Long id) {
        repository.deleteById(id);
    }

    private void validar(AdministradorCasaDTO dto) {
        if (dto.nome() == null || dto.nome().isBlank()) {
            throw new IllegalArgumentException("Nome é obrigatório.");
        }
        if (dto.email() == null || dto.email().isBlank()) {
            throw new IllegalArgumentException("E-mail é obrigatório.");
        }
        if (dto.nivelAcesso() == null || dto.nivelAcesso().isBlank()) {
            throw new IllegalArgumentException("Nível de acesso é obrigatório.");
        }
    }
}
