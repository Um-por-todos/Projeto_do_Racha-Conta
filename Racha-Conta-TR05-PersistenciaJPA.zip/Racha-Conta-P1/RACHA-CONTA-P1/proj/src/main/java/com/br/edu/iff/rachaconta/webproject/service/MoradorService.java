package com.br.edu.iff.rachaconta.webproject.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.br.edu.iff.rachaconta.webproject.dto.MoradorDTO;
import com.br.edu.iff.rachaconta.webproject.model.Casa;
import com.br.edu.iff.rachaconta.webproject.model.Morador;
import com.br.edu.iff.rachaconta.webproject.repository.CasaRepository;
import com.br.edu.iff.rachaconta.webproject.repository.MoradorRepository;

@Service
public class MoradorService {

    private final MoradorRepository repository;
    private final CasaRepository casaRepository;

    public MoradorService(MoradorRepository repository, CasaRepository casaRepository) {
        this.repository = repository;
        this.casaRepository = casaRepository;
    }

    public List<Morador> listar() {
        return repository.findAll();
    }

    public Morador buscar(Long id) {
        return repository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Morador não encontrado."));
    }

    @Transactional
    public Morador salvar(MoradorDTO dto) {
        validar(dto);
        Morador morador = new Morador(null, dto.nome(), dto.email(), dto.ativo());
        return salvarEVincular(morador, dto.casaId());
    }

    @Transactional
    public Morador atualizar(Long id, MoradorDTO dto) {
        validar(dto);
        Morador morador = buscar(id);
        morador.setNome(dto.nome());
        morador.setEmail(dto.email());
        morador.setAtivo(dto.ativo());

        desvincularDasCasas(id);
        return salvarEVincular(morador, dto.casaId());
    }

    @Transactional
    public void excluir(Long id) {
        desvincularDasCasas(id);
        repository.deleteById(id);
    }

    private Morador salvarEVincular(Morador morador, Long casaId) {
        Morador salvo = repository.save(morador);

        if (casaId == null) {
            return salvo;
        }

        Casa casa = casaRepository.findById(casaId)
            .orElseThrow(() -> new IllegalArgumentException("Casa não encontrada."));
        casa.adicionarMorador(salvo.getId());
        casaRepository.save(casa);

        return salvo;
    }

    private void desvincularDasCasas(Long moradorId) {
        casaRepository.findAll().stream()
            .filter(casa -> casa.getMoradoresIds().contains(moradorId))
            .forEach(casa -> {
                casa.removerMorador(moradorId);
                casaRepository.save(casa);
            });
    }

    private void validar(MoradorDTO dto) {
        if (dto.nome() == null || dto.nome().isBlank()) {
            throw new IllegalArgumentException("Nome é obrigatório.");
        }
        if (dto.email() == null || dto.email().isBlank()) {
            throw new IllegalArgumentException("E-mail é obrigatório.");
        }
    }
}
