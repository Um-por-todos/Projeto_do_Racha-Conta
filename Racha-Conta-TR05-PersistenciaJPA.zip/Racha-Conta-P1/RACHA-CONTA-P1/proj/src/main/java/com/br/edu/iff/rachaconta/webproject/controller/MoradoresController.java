package com.br.edu.iff.rachaconta.webproject.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.br.edu.iff.rachaconta.webproject.dto.MoradorDTO;
import com.br.edu.iff.rachaconta.webproject.service.CasaService;
import com.br.edu.iff.rachaconta.webproject.service.MoradorService;

@Controller
@RequestMapping("/moradores")
public class MoradoresController {

    private final MoradorService service;
    private final CasaService casaService;

    public MoradoresController(MoradorService service, CasaService casaService) {
        this.service = service;
        this.casaService = casaService;
    }

    @GetMapping
    public String lista(Model model) {
        model.addAttribute("moradores", service.listar());
        return "moradores/lista";
    }

    @GetMapping("/novo")
    public String novo(Model model) {
        model.addAttribute("morador", new MoradorDTO("", "", true, null));
        model.addAttribute("casas", casaService.listar());
        model.addAttribute("acao", "/moradores");
        return "moradores/form";
    }

    @PostMapping
    public String criar(
        @RequestParam String nome,
        @RequestParam String email,
        @RequestParam(defaultValue = "false") boolean ativo,
        @RequestParam(required = false) Long casaId
    ) {
        service.salvar(new MoradorDTO(nome, email, ativo, casaId));
        return "redirect:/moradores";
    }

    @GetMapping("/{id}")
    public String detalhe(@PathVariable Long id, Model model) {
        model.addAttribute("morador", service.buscar(id));
        return "moradores/detalhe";
    }

    @GetMapping("/{id}/editar")
    public String editar(@PathVariable Long id, Model model) {
        model.addAttribute("morador", service.buscar(id));
        model.addAttribute("casas", casaService.listar());
        return "moradores/editar";
    }

    @PostMapping("/{id}")
    public String atualizar(
        @PathVariable Long id,
        @RequestParam String nome,
        @RequestParam String email,
        @RequestParam(defaultValue = "false") boolean ativo,
        @RequestParam(required = false) Long casaId
    ) {
        service.atualizar(id, new MoradorDTO(nome, email, ativo, casaId));
        return "redirect:/moradores";
    }

    @PostMapping("/{id}/excluir")
    public String excluir(@PathVariable Long id) {
        service.excluir(id);
        return "redirect:/moradores";
    }
}
