package com.br.edu.iff.rachaconta.webproject.controller;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.br.edu.iff.rachaconta.webproject.dto.PagamentoDTO;
import com.br.edu.iff.rachaconta.webproject.service.DividaService;
import com.br.edu.iff.rachaconta.webproject.service.PagamentoService;

@Controller
@RequestMapping("/pagamentos")
public class PagamentosController {

    private final PagamentoService service;
    private final DividaService dividaService;

    public PagamentosController(PagamentoService service, DividaService dividaService) {
        this.service = service;
        this.dividaService = dividaService;
    }

    @GetMapping
    public String lista(Model model) {
        model.addAttribute("pagamentos", service.listar());
        return "pagamentos/lista";
    }

    @GetMapping("/novo")
    public String novo(Model model) {
        model.addAttribute(
            "dividas",
            dividaService.listar().stream().filter(divida -> !divida.isQuitada()).toList()
        );
        return "pagamentos/form";
    }

    @PostMapping
    public String criar(
        @RequestParam BigDecimal valorPago,
        @RequestParam Long dividaId,
        @RequestParam(required = false) LocalDate dataPagamento,
        @RequestParam(defaultValue = "false") boolean confirmado
    ) {
        service.salvar(new PagamentoDTO(
            valorPago,
            dataPagamento,
            dividaId,
            confirmado
        ));
        return "redirect:/pagamentos";
    }

    @PostMapping("/{id}/confirmar")
    public String confirmar(@PathVariable Long id) {
        service.confirmar(id);
        return "redirect:/pagamentos";
    }
}
