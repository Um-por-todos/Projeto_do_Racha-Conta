package com.br.edu.iff.rachaconta.webproject.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.br.edu.iff.rachaconta.webproject.dto.CasaDTO;
import com.br.edu.iff.rachaconta.webproject.model.Casa;
import com.br.edu.iff.rachaconta.webproject.model.Morador;
import com.br.edu.iff.rachaconta.webproject.repository.CasaRepository;
import com.br.edu.iff.rachaconta.webproject.repository.MoradorRepository;

@Service
public class CasaService {

    private final CasaRepository repository;
    private final MoradorRepository moradorRepository;

    public CasaService(CasaRepository repository, MoradorRepository moradorRepository) {
        this.repository = repository;
        this.moradorRepository = moradorRepository;
    }

    public List<Casa> listar() {
        return repository.findAll();
    }

    public Casa buscar(Long id) {
        return repository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Casa não encontrada."));
    }

    public Casa salvar(CasaDTO dto) {
        validar(dto);
        return repository.save(new Casa(null, dto.nome(), dto.endereco()));
    }

    public Casa atualizar(Long id, CasaDTO dto) {
        validar(dto);
        Casa casa = buscar(id);
        casa.setNome(dto.nome());
        casa.setEndereco(dto.endereco());
        return repository.save(casa);
    }

    @Transactional
    public void adicionarMorador(Long casaId, Long moradorId) {
        Casa casa = buscar(casaId);
        moradorRepository.findById(moradorId)
            .orElseThrow(() -> new IllegalArgumentException("Morador não encontrado."));

        casa.adicionarMorador(moradorId);
        repository.save(casa);
    }

    public List<Morador> listarMoradores(Long casaId) {
        Casa casa = buscar(casaId);
        return casa.getMoradoresIds().stream()
            .map(moradorRepository::findById)
            .flatMap(Optional::stream)
            .toList();
    }

    public void excluir(Long id) {
        repository.deleteById(id);
    }

    private void validar(CasaDTO dto) {
        if (dto.nome() == null || dto.nome().isBlank()) {
            throw new IllegalArgumentException("Nome é obrigatório.");
        }
        if (dto.endereco() == null || dto.endereco().isBlank()) {
            throw new IllegalArgumentException("Endereço é obrigatório.");
        }
    }
}
