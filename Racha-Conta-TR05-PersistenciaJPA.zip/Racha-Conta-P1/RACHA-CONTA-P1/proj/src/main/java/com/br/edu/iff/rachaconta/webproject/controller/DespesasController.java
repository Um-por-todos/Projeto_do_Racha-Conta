package com.br.edu.iff.rachaconta.webproject.controller;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.br.edu.iff.rachaconta.webproject.dto.DespesaDTO;
import com.br.edu.iff.rachaconta.webproject.service.CasaService;
import com.br.edu.iff.rachaconta.webproject.service.DespesaService;
import com.br.edu.iff.rachaconta.webproject.service.MoradorService;

@Controller
@RequestMapping("/despesas")
public class DespesasController {

    private final DespesaService service;
    private final CasaService casaService;
    private final MoradorService moradorService;

    public DespesasController(
        DespesaService service,
        CasaService casaService,
        MoradorService moradorService
    ) {
        this.service = service;
        this.casaService = casaService;
        this.moradorService = moradorService;
    }

    @GetMapping
    public String lista(Model model) {
        model.addAttribute("despesas", service.listar());
        model.addAttribute("moradores", moradorService.listar());

        Map<Long, String> pagadorNomes = new HashMap<>();
        moradorService.listar().forEach(
            morador -> pagadorNomes.put(morador.getId(), morador.getNome())
        );
        model.addAttribute("pagadorNomes", pagadorNomes);
        return "despesas/lista";
    }

    @GetMapping("/novo")
    public String novo(Model model) {
        model.addAttribute("casas", casaService.listar());
        model.addAttribute("moradores", moradorService.listar());
        return "despesas/form";
    }

    @PostMapping
    public String criar(
        @RequestParam BigDecimal valorTotal,
        @RequestParam String descricao,
        @RequestParam String tipo,
        @RequestParam Long pagadorId,
        @RequestParam Long casaId,
        @RequestParam(required = false) LocalDate data
    ) {
        service.salvar(new DespesaDTO(
            valorTotal,
            descricao,
            tipo,
            pagadorId,
            casaId,
            data
        ));
        return "redirect:/despesas";
    }

    @GetMapping("/{id}")
    public String detalhe(@PathVariable Long id, Model model) {
        var despesa = service.buscar(id);
        model.addAttribute("despesa", despesa);
        model.addAttribute(
            "pagadorNome",
            moradorService.buscar(despesa.getPagadorId()).getNome()
        );
        return "despesas/detalhe";
    }

    @GetMapping("/{id}/editar")
    public String editar(@PathVariable Long id, Model model) {
        model.addAttribute("despesa", service.buscar(id));
        model.addAttribute("casas", casaService.listar());
        model.addAttribute("moradores", moradorService.listar());
        return "despesas/editar";
    }

    @PostMapping("/{id}")
    public String atualizar(
        @PathVariable Long id,
        @RequestParam BigDecimal valorTotal,
        @RequestParam String descricao,
        @RequestParam String tipo,
        @RequestParam Long pagadorId,
        @RequestParam Long casaId,
        @RequestParam(required = false) LocalDate data
    ) {
        service.atualizar(id, new DespesaDTO(
            valorTotal,
            descricao,
            tipo,
            pagadorId,
            casaId,
            data
        ));
        return "redirect:/despesas";
    }

    @PostMapping("/{id}/excluir")
    public String excluir(@PathVariable Long id) {
        service.excluir(id);
        return "redirect:/despesas";
    }
}
