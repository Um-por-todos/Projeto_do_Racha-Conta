package com.br.edu.iff.rachaconta.webproject.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record DespesaDTO(
    @NotNull(message = "O valor total é obrigatório.")
    @DecimalMin(value = "0.01", message = "O valor total deve ser maior que zero.")
    BigDecimal valorTotal,

    @NotBlank(message = "A descrição é obrigatória.")
    @Size(min = 2, max = 150, message = "A descrição deve ter entre 2 e 150 caracteres.")
    String descricao,

    @NotBlank(message = "O tipo é obrigatório.")
    @Size(max = 50, message = "O tipo deve ter no máximo 50 caracteres.")
    String tipo,

    @NotNull(message = "Selecione quem pagou a despesa.")
    Long pagadorId,

    @NotNull(message = "Selecione a casa da despesa.")
    Long casaId,

    LocalDate data
) {
}
