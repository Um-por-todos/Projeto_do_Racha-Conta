package com.br.edu.iff.rachaconta.webproject.dto;

import java.math.BigDecimal;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

public record DividaDTO(
    @NotNull(message = "O valor da dívida é obrigatório.")
    @DecimalMin(value = "0.01", message = "O valor da dívida deve ser maior que zero.")
    BigDecimal valor,

    @NotNull(message = "A despesa é obrigatória.")
    Long despesaId,

    @NotNull(message = "O devedor é obrigatório.")
    Long devedorId,

    @NotNull(message = "O credor é obrigatório.")
    Long credorId
) {
}
