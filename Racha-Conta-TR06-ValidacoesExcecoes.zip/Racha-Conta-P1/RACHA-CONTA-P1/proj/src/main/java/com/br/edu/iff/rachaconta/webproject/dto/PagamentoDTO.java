package com.br.edu.iff.rachaconta.webproject.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

public record PagamentoDTO(
    @NotNull(message = "O valor pago é obrigatório.")
    @DecimalMin(value = "0.01", message = "O valor pago deve ser maior que zero.")
    BigDecimal valorPago,

    LocalDate dataPagamento,

    @NotNull(message = "Selecione uma dívida.")
    Long dividaId,

    boolean confirmado
) {
}
